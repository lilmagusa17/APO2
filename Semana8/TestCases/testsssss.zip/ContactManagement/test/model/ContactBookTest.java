package model;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContactBookTest {

    private void searchScenary1() {
        ContactBook newContactBook = new ContactBook();
    }

    @Test
    public void testSearch(){
        searchScenary1();



    }

}
