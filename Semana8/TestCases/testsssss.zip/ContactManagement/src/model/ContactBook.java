package model;

import java.util.ArrayList;
import java.util.List;

public class ContactBook {

    ArrayList<Contact> contacts;

    public ContactBook() {
        contacts = new ArrayList<>();
    }

    public boolean addContact(String email, String phone) {

        return false;
    }

    public Contact search(String email) {

        return null;
    }


    public Contact remove(String email) {

        return null;
    }


    public ArrayList<Contact> getContacts() {

        return null;
    }




}
